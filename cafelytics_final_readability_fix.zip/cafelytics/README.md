# Cafelytics

A stock-recommendation dashboard styled as a café order ticket. Predicts tomorrow's stock level per product, shows the reasoning behind the number, breaks down the cost of getting it wrong, and answers live what-if questions.

## Data source

`data/sales_history.csv` is built from a **real public coffee-vending-machine sales dataset** —
3,636 individual transactions from Mar 2024 to Mar 2025, sourced from:
https://github.com/mehmetkahya0/coffee-shop-business-intelligence

Raw transactions were aggregated into daily per-product unit counts (one row per product per
calendar day, including zero-sales days, so the series is a true continuous daily history).
`data/products.csv` keeps the 4 highest-volume products from that dataset; `base_units`,
`daily_growth`, and `weekend_boost` in that file are **real computed statistics** from the
data (mean daily units, linear trend slope, weekend-vs-weekday ratio) — reference figures only,
not used by the forecasting code itself.

Because it's a real dataset, the "forecast" is for the day *after the dataset's last recorded
date* (23 Mar 2025), not after today's real-world date — see `forecast()` in `script.js`.

## Files

```
demandshield/
├── index.html            structure only
├── style.css              all styling
├── script.js               all logic: CSV loading, forecasting, cost calc, what-if handling
├── data/
│   ├── products.csv         product catalog (name, base volume, growth, weekend boost)
│   └── sales_history.csv    60 days × 4 products of daily units sold
└── README.md
```

## Running it

Browsers block `fetch()` on files opened directly (`file://...`), so this needs a tiny local server — one command, no install if you have Python:

```bash
cd demandshield
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser.

(No Python? `npx serve` works the same way if you have Node.)

## Using your own data

Replace the two CSVs — no code changes needed:

- **`data/products.csv`** — one row per product: `product_id,name,base_units,daily_growth,weekend_boost`
- **`data/sales_history.csv`** — one row per day per product: `date,product_id,units_sold`

The forecast logic (in `script.js`) recomputes everything from whatever's in these files: historical average, recent 7-day average, and a day-of-week adjustment factor derived from the actual data — nothing is hardcoded.

## How the forecast works

1. **Historical average** — mean of all units sold in the dataset.
2. **Recent 7-day average** — mean of the last 7 days, to weight recent trend over old data.
3. **Day-of-week factor** — average sales on that weekday ÷ overall average, applied to the recent average.
4. **Predicted demand** = recent 7-day average × day-of-week factor.
5. **Range** = predicted ± one standard deviation of historical daily sales.

## Cost analysis

- Understock cost = shortfall units × margin lost per unmet unit (editable in the UI)
- Overstock cost = surplus units × waste cost per excess unit (editable in the UI)

Shown at three stock levels: understock (−15%), balanced/recommended (the forecast itself), and overstock (+15%).

## What-if console

Parses plain-English scenarios:
- `"demand increases by 20%"` → recalculates with an adjustment factor
- `"only 50 units available"` → checks the forecast against a hard stock cap
- `"what if there's a festival tomorrow?"` → **honest fallback** — the dataset has no event/weather data, so it says so instead of guessing


## Updated demo features
- Includes 12 café menu items instead of only four.
- Includes a local demo dataset in `data/` so the dashboard can run immediately.
- Each selected product has an image upload area. Images are previewed for the current browser session and do not change the forecasting calculation.
- Forecasting, explainability, risk/cost analysis, and what-if behavior remain based on the existing transparent rules.


## Codeathon-ready functionality in V4

- Warm premium coffee-house visual theme inspired by modern café POS dashboards.
- 12 menu items loaded from `data/products.csv`.
- Product-level forecast using historical average, recent 7-day average, and day-of-week adjustment.
- Explainability trail showing the values behind each recommendation.
- Visual analytics: 14-day sales trend, under/recommended/over stock comparison, and planning insights.
- Product image upload and preview for the selected menu item. Images are visual references and do not alter the forecast.
- What-if decision engine supports: percentage demand changes, double/half demand, stock limits, and transparent unsupported-data responses for weather/events.
- Scenario results update the recommendation, KPI cards, manager note, and risk/cost view.
- Reset button returns the dashboard to the baseline forecast.

## Demo narrative

Cafelytics is not claiming to predict every real-world event. It converts available sales history into an explainable planning recommendation, then lets a manager test measurable assumptions and understand the operational consequence of limited stock.


## Prototype interaction guide
- Select a menu item, then review the forecast and reasoning panel.
- Use What-if Lab for measurable assumptions such as `demand increases by 20%` or `only 50 units available`.
- Use BrewBuddy chat for explanations and quick scenario summaries.
- The image upload is a visual reference and does not change the forecast.
- Run through a local server: `python -m http.server 8000`, then open `http://localhost:8000`.
